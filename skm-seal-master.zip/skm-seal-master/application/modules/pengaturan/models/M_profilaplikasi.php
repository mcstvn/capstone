<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_profilaplikasi extends CI_Model {
	 
	
}

/* End of file M_loket.php */
/* Location: ./application/modules/loket/models/M_loket.php */